CREATE DATABASE IF NOT EXISTS pos_db;
USE pos_db;

CREATE TABLE customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    created_at DATETIME NOT NULL
);

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    created_at DATETIME NOT NULL
);

INSERT INTO customers (full_name, email, phone, created_at) VALUES
('Juan Dela Cruz', 'juan@example.com', '09171234567', '2026-10-01 09:00:00'),
('Maria Santos', 'maria@example.com', '09181234567', '2026-10-01 09:15:00'),
('Carlo Reyes', 'carlo@example.com', '09191234567', '2026-10-02 10:00:00'),
('Angela Garcia', 'angela@example.com', '09201234567', '2026-10-02 10:30:00'),
('Miguel Mendoza', 'miguel@example.com', '09211234567', '2026-10-03 11:00:00');

INSERT INTO users (username, full_name, created_at) VALUES
('admin', 'System Administrator', '2026-10-01 08:00:00'),
('jdelacruz', 'Juan Dela Cruz', '2026-10-01 08:30:00'),
('msantos', 'Maria Santos', '2026-10-01 08:45:00'),
('creyes', 'Carlo Reyes', '2026-10-02 09:00:00'),
('agarcia', 'Angela Garcia', '2026-10-03 09:30:00');
