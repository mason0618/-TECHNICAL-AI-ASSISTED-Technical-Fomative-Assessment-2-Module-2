<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Accounts | POS Management System</title>
    <link rel="stylesheet" href="<?= base_url('css/style.css') ?>">
</head>
<body>
<header class="site-header">
    <div class="header-content">
        <a class="brand" href="<?= base_url('/') ?>">POS <span>System</span></a>
        <nav class="main-nav">
            <a href="<?= base_url('/') ?>">Home</a>
            <a class="active" href="<?= base_url('customers') ?>">Customers</a>
            <a href="<?= base_url('users') ?>">Users</a>
            <a href="<?= base_url('about') ?>">About</a>
        </nav>
    </div>
</header>

<main class="page-container">
    <div class="page-heading">
        <h1>Customer Accounts</h1>
        <p>List of customers saved in the database.</p>
    </div>
    <section class="table-card">
        <table>
            <thead>
                <tr>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($customers as $customer): ?>
                <tr>
                    <td><?= esc($customer['full_name']) ?></td>
                    <td><?= esc($customer['email']) ?></td>
                    <td><?= esc($customer['phone']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </section>
</main>

<footer class="site-footer">CodeIgniter 4 POS Management System</footer>
</body>
</html>
