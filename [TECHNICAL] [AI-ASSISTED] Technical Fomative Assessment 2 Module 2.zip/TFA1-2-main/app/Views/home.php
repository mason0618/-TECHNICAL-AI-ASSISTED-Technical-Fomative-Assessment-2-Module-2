<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>POS Management System</title>
    <link rel="stylesheet" href="<?= base_url('css/style.css') ?>">
</head>
<body>
<header class="site-header">
    <div class="header-content">
        <a class="brand" href="<?= base_url('/') ?>">POS <span>System</span></a>
        <nav class="main-nav">
            <a class="active" href="<?= base_url('/') ?>">Home</a>
            <a href="<?= base_url('customers') ?>">Customers</a>
            <a href="<?= base_url('users') ?>">Users</a>
            <a href="<?= base_url('about') ?>">About</a>
        </nav>
    </div>
</header>

<main class="page-container">
    <section class="welcome-card">
        <h1>POS Management System</h1>
        <p>Welcome to the Point-of-Sale Management System. Use the links below to view the customer and user accounts.</p>
        <div class="quick-links">
            <a class="quick-link" href="<?= base_url('customers') ?>">View Customer Accounts</a>
            <a class="quick-link" href="<?= base_url('users') ?>">View User Accounts</a>
        </div>
    </section>
</main>

<footer class="site-footer">CodeIgniter 4 POS Management System</footer>
</body>
</html>
