<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Accounts | POS Management System</title>
    <link rel="stylesheet" href="<?= base_url('css/style.css') ?>">
</head>
<body>
<header class="site-header">
    <div class="header-content">
        <a class="brand" href="<?= base_url('/') ?>">POS <span>System</span></a>
        <nav class="main-nav">
            <a href="<?= base_url('/') ?>">Home</a>
            <a href="<?= base_url('customers') ?>">Customers</a>
            <a class="active" href="<?= base_url('users') ?>">Users</a>
            <a href="<?= base_url('about') ?>">About</a>
        </nav>
    </div>
</header>

<main class="page-container">
    <div class="page-heading">
        <h1>User Accounts</h1>
        <p>List of users saved in the database.</p>
    </div>
    <section class="table-card">
        <table>
            <thead>
                <tr>
                    <th>Username</th>
                    <th>Full Name</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                <tr>
                    <td><?= esc($user['username']) ?></td>
                    <td><?= esc($user['full_name']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </section>
</main>

<footer class="site-footer">CodeIgniter 4 POS Management System</footer>
</body>
</html>
